package com.example.stockers;

/**
 * Created by RyanMini on 3/4/17.
 * doesn't do anything
 */

public class Stock {

    String name;
    String ticker;


}
